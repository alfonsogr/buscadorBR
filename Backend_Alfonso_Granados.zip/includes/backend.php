<?php
require_once("claseBuscador.php");

if(!empty($_POST["case"])){
	$enCasoDe = $_POST["case"];
}else{
	$enCasoDe = 0;
}

switch ($enCasoDe) {
	case 'mostrarTodo':
		$buscadorBR = new buscadorBR("../data-1.json");
		$rps = json_encode(array("rps" => 1, "result" => $buscadorBR->datosJson()));

		echo $rps;
		break;

	case 'DatosCiudad':
		$buscadorBR = new buscadorBR("../data-1.json");
		$datos 			= $buscadorBR->datosJson();
		$tipos      = $ciudad= array();

		foreach($datos as $data){
			if(!empty($data["Ciudad"])){
				if(count($ciudad)>0){
					if(!in_array($data["Ciudad"], $ciudad)){
						array_push($ciudad, $data["Ciudad"]);
					}
				}   else{
					    array_push($ciudad, $data["Ciudad"]);
				}
			}

			if(!empty($data["Tipo"])){
				if(count($tipos)>0){
					if(!in_array($data["Tipo"], $tipos)){
						array_push($tipos, $data["Tipo"]);
					}
				}   else{
					    array_push($tipos, $data["Tipo"]);
				}
			}
		}

		$rps = json_encode(array("rps" => 1, "result" => array($ciudad, $tipos)));

		echo $rps;
		break;

	case 'DatosFiltro':

		$buscadorBR   = new buscadorBR("../data-1.json");
		$datos 			  = $buscadorBR->datosJson();
		$ciudad 		  = $_POST["ciudad"];
		$tipo 			  = $_POST["tipo"];
		$precio 		  = explode(";", $_POST["precio"]);
		$mostrarDatos = array();

		foreach($datos as $data){
			$flag_ciudad = false;
			$flag_tipo 	= false;
			$flag_precio = false;

			if(!empty($ciudad)){
				if($data["Ciudad"]==$ciudad){
					$flag_ciudad = true;
				}
			}   else{
				    $flag_ciudad = true;
			}

			if(!empty($tipo)){
				if($data["Tipo"]==$tipo){
					$flag_tipo = true;
				}
			}   else{
				    $flag_tipo = true;
			}

			$precioChr = str_replace(array("$",","), array("",""), $data["Precio"]);
			if($precioChr>=$precio[0] && $precioChr<=$precio[1]){
				$flag_precio = true;
			}

			if($flag_ciudad && $flag_tipo && $flag_precio){
				array_push($mostrarDatos, $data);
			}

			$rps = json_encode(array("rps" => 1, "result" => $mostrarDatos));
		}

		echo $rps;
		break;

}
?>
