<?php
class buscadorBR{

	public $pathJson;

	function __construct($pathJson){
		$this->pathJson = $pathJson;
	}

	public function datosJson(){
		$data 		= file_get_contents($this->pathJson);
		$productos 	= json_decode($data, true);

		return $productos;
	}
}
?>
